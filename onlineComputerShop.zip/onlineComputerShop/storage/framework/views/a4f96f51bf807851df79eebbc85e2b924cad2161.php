<?php $__env->startSection('content'); ?>

<h2>Details Product</h2>

	<table border="0">
		<tr>
			<td>Products Id :</td>
			<td><?php echo e($std['products_id']); ?></td>
		</tr>
		<tr>
			<td>Products Name :</td>
			<td><?php echo e($std['p_name']); ?></td>
		</tr>
		<tr>
			<td>Products Quantity :</td>
			<td><?php echo e($std['p_quantity']); ?></td>
		</tr>
		<tr>
			<td>Products Price:</td>
			<td><?php echo e($std['p_price']); ?></td>
		</tr>
		
		<tr>
			<td>Products Menufacture:</td>
			<td><?php echo e($std['menufac']); ?></td>
		</tr>
</table>

<br>
<h3>Give A Review</h3>
<form method="post">

		<?php echo e(csrf_field()); ?>

		
		<table>
			<tr>
				<td>Review Star</td>
				<td><input type="text" name="reviewstar" placeholder="1-5"></td>
			</tr>
			<tr>
				<td>Comments</td>
				<td><input type="text" name="review"></td>
			</tr>
			 <input type="hidden" id="productid" name="productid" value="<?php echo e($std['products_id']); ?>">
			<tr>
				<td><input type="submit" name="submit" value="Submit"></td>
				<td></td>
			</tr>
		</table>
	</form>
	
	
<br>
<h3>All Review</h3>

<?php $__currentLoopData = $review; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		Review Star :<?php echo e($rev['reviewstar']); ?> <br>
		Comment :<?php echo e($rev['review']); ?><br>
		Author ;<?php echo e($rev['customer']); ?><br>
		
	<a href="<?php echo e(route('home.deletereview',  $rev['id'])); ?>">Delete</a>
		
		<br><br>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
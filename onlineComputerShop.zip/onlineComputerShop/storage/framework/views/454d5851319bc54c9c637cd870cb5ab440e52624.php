<?php $__env->startSection('content'); ?>

	<h2>Edit Products</h2>

	<a href="<?php echo e(route('products.stdlist')); ?>">Back</a> |
	<a href="/logout">logout</a>

<form method="post">
<?php echo e(@csrf_field()); ?>

	<table border="0">
		<tr>
			<td>Products Id</td>
			<td><?php echo e($std['products_id']); ?></td>
		</tr>
		<tr>
			<td>Products Name</td>
			<td><input type="text" name="pname" value="<?php echo e($std['p_name']); ?>"></td>
		</tr>
		<tr>
			<td>Name</td>
			<td><input type="text" name="pquantity" value="<?php echo e($std['p_quantity']); ?>"></td>
		</tr>
		<tr>
			<td>Contact</td>
			<td><input type="text" name="pprice" value="<?php echo e($std['p_price']); ?>"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="save" value="Save"></td>
		</tr>
</table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
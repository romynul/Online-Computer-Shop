<?php $__env->startSection('content'); ?>


	<h2>Details Employee</h2>



	<table border="0">
		<tr>
			<td>UserId :</td>
			<td><?php echo e($std['id']); ?></td>
		</tr>
		<tr>
			<td>Username :</td>
			<td><?php echo e($std['username']); ?></td>
		</tr>
		<tr>
			<td>Name :</td>
			<td><?php echo e($std['emp_name']); ?></td>
		</tr>
		<tr>
			<td>Contact :</td>
			<td><?php echo e($std['contact_no']); ?></td>
		</tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
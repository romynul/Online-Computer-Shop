<?php $__env->startSection('content'); ?>

	

<h3>Search Results</h3>

<input type="text" class="form-controller" id="search" name="search"></input>

<table class="table table-bordered table-hover">
<thead>
<tr>
<th>ID</th>
<th>Product Name</th>
<th>Brand</th>
<th>Price</th>
<th>Catagories</th>

</tr>
</thead>
<tbody>
</tbody>
</table>

<script type="text/javascript">
$('#search').on('keyup',function(){
$value=$(this).val();
$.ajax({
type : 'get',
url : '<?php echo e(URL::to('search')); ?>',
data:{'search':$value},
success:function(data){
$('tbody').html(data);
}
});
})
</script>
<script type="text/javascript">
$.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!DOCTYPE html>
<html>
<head>
<meta name="_token" content="<?php echo e(csrf_token()); ?>">
<title>Live Search</title>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
</head>
<body>
	<h1>Welcome <?php echo e(session('user')); ?></h1> 

	
	<a href="<?php echo e(route('products.index')); ?>">Home</a> |
	<a href="<?php echo e(route('products.search')); ?>">Search Products</a> |
	<a href="<?php echo e(route('products.stdlist')); ?>">All Products</a> |
	<a href="<?php echo e(route('products.cart')); ?>">Cart</a> |
	<a href="/logout">logout</a>
	<br>
	Catagories :
	<a href="<?php echo e(route('products.laptop')); ?>">Laptop</a> |
	<a href="<?php echo e(route('products.ram')); ?>">Ram</a> |
	<a href="<?php echo e(route('products.casing')); ?>">Casing</a> |
	<a href="<?php echo e(route('products.storage')); ?>">Storage</a> |
	<a href="<?php echo e(route('products.monitor')); ?>">Monitor</a> |

	<?php echo $__env->yieldContent('content'); ?>
	
</body>
</html>
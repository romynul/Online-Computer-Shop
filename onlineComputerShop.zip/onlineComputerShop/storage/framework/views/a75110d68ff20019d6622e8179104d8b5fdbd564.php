<?php $__env->startSection('content'); ?>

	<h2>Delete Products</h2>
<form method="post">
	<?php echo e(@csrf_field()); ?>

	<table border="0">
	<tr>
			<td>Products Id :</td>
			<td><?php echo e($std['products_id']); ?></td>
		</tr>
		<tr>
			<td>Products Name :</td>
			<td><?php echo e($std['p_name']); ?></td>
		</tr>
		<tr>
			<td>Products Quantity :</td>
			<td><?php echo e($std['p_quantity']); ?></td>
		</tr>
		<tr>
			<td>Products Price:</td>
			<td><?php echo e($std['p_price']); ?></td>
		</tr>
		
</table>
	<h3>Are you sure?</h3>
	<input type="submit" name="delete" value="Confirm">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<br>
<h2> Features Products</h2>
<table class="table table-bordered table-hover">
		<tr>
			<td>Products ID</td>
			<td>Products Name</td>
			<td>Products Quantity</td>
			<td>Products Price</td>
			<td>Products Brand</td>
			<td>Products Catagory</td>
			<td>Action</td>
		</tr>
		<?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($value['products_id']); ?></td>
			<td><?php echo e($value['p_name']); ?></td>
			<td><?php echo e($value['p_quantity']); ?></td>
			<td><?php echo e($value['p_price']); ?></td>
			<td><?php echo e($value['brand']); ?></td>
			<td><?php echo e($value['catagories']); ?></td>
			<td>
				<a href="<?php echo e(route('products.details', $value['products_id'])); ?>">Details</a> |
				<a href="<?php echo e(route('products.cartadd', $value['products_id'])); ?>">Add To Cart</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
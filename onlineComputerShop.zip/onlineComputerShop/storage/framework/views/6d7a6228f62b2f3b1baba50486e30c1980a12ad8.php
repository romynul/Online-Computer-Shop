<?php $__env->startSection('content'); ?>

	<h2>Products List:</h2>
	
	<a href="/products">Back</a> |
	<a href="/logout">logout</a>
	
	<form method="post">

		<!--<?php echo e(csrf_field()); ?> -->
		<!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> --> 
		<?php echo e(csrf_field()); ?>

		
		<table>
			
			<td>Brand </td>
				<td><select class="form-control selectric" name="brand">
                        
                        <option value="Dell">Dell</option>
                        <option value="Hp">Hp</option>
                        <option value="Asus">Asus</option>
                        
                      </select></td>
			
				<td><input type="submit" name="submit" value=" Submit"></td>
				<td></td>
			
		</table>
	</form>

	<table class="table table-bordered table-hover">
		<tr>
			<td>Products ID</td>
			<td>Products Name</td>
			<td>Products Quantity</td>
			<td>Products Price</td>
			<td>Products Brand</td>
			<td>Products Catagory</td>
			<td>Action</td>
		</tr>
		<?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($value['products_id']); ?></td>
			<td><?php echo e($value['p_name']); ?></td>
			<td><?php echo e($value['p_quantity']); ?></td>
			<td><?php echo e($value['p_price']); ?></td>
			<td><?php echo e($value['brand']); ?></td>
			<td><?php echo e($value['catagories']); ?></td>
			<td>
				<a href="<?php echo e(route('products.details', $value['products_id'])); ?>">Details</a> |
				<a href="<?php echo e(route('products.cartadd', $value['products_id'])); ?>">Add To Cart</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
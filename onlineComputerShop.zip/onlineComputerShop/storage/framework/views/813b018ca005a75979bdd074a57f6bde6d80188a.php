<?php $__env->startSection('content'); ?>

	<h2>Edit Employee</h2>



<form method="post">
	<table border="0">
		<tr>
			<td>UserId</td>
			<td><?php echo e($std['id']); ?></td>
		</tr>
		<tr>
			<td>Username</td>
			<td><input type="text" name="uname" value="<?php echo e($std['username']); ?>"></td>
		</tr>
		<tr>
			<td>Name</td>
			<td><input type="text" name="name" value="<?php echo e($std['emp_name']); ?>"></td>
		</tr>
		<tr>
			<td>Contact</td>
			<td><input type="text" name="contact" value="<?php echo e($std['contact_no']); ?>"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="save" value="Save"></td>
		</tr>
</table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
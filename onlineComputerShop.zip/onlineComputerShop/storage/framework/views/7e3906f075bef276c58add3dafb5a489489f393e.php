<!DOCTYPE html>
<html>
<head>
<meta name="_token" content="<?php echo e(csrf_token()); ?>">
<title>Live Search</title>
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
</head>
<body>

<h1>Welcome <?php echo e(session('user')); ?></h1> 

	<a href="<?php echo e(route('home.index')); ?>">Home</a> |
	<a href="<?php echo e(route('home.stdlist')); ?>">Customer List</a> |
	<a href="<?php echo e(route('home.search')); ?>">Search Products</a> |
	<a href="<?php echo e(route('home.addc')); ?>">Add Products</a> |
	<a href="<?php echo e(route('home.stdlistc')); ?>">All Products</a> |
	<a href="/logout">logout</a>

	
	<?php echo $__env->yieldContent('content'); ?>

</body>
</html>
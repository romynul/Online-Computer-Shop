<?php $__env->startSection('content'); ?>


	<table class="table table-bordered table-hover">
		<tr>
			<td>ID</td>
			<td>Name</td>
			<td>Contact No</td>
			<td>Action</td>
		</tr>
		<?php $__currentLoopData = $std; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($value['id']); ?></td>
			<td><?php echo e($value['emp_name']); ?></td>
			<td><?php echo e($value['contact_no']); ?></td>
			<td>
				<a href="<?php echo e(route('home.edit', $value['id'])); ?>">Edit</a> |
				<a href="<?php echo e(route('home.delete', $value['id'])); ?>">Delete</a> |
				<a href="<?php echo e(route('home.details', $value['id'])); ?>">Details</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.customer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>